Working as of 03/18/2020!

Go to your Facebook profile.

Click "Friends".

Click the red X next to anyone you want to unfriend.

Warning! No confirm button appears. One click will unfriend.

If you do not see the extension appear, please try refreshing the page.

Like this extension? Leave a rating/review!

Follow me! @JoeyFenny